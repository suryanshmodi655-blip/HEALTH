import { v } from "convex/values";
import { query, mutation, internalAction } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";

// Get user notifications
export const getUserNotifications = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("notifications")
      .withIndex("by_user_and_sent", (q) => q.eq("userId", userId).eq("sent", false))
      .order("desc")
      .take(20);
  },
});

// Mark notification as read
export const markNotificationAsRead = mutation({
  args: { notificationId: v.id("notifications") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const notification = await ctx.db.get(args.notificationId);
    if (!notification || notification.userId !== userId) {
      throw new Error("Notification not found or unauthorized");
    }

    await ctx.db.patch(args.notificationId, { sent: true });
    return "Notification marked as read";
  },
});

// Send appointment reminder (internal function)
export const sendAppointmentReminder = internalAction({
  args: { appointmentId: v.id("appointments") },
  handler: async (ctx, args) => {
    const appointment = await ctx.runQuery(internal.appointments.getAppointmentById, {
      appointmentId: args.appointmentId,
    });

    if (!appointment || appointment.status !== "scheduled") return;

    const doctor = await ctx.runQuery(internal.doctors.getDoctorByIdInternal, {
      doctorId: appointment.doctorId,
    });

    if (!doctor) return;

    await ctx.runMutation(internal.notifications.createNotification, {
      userId: appointment.userId,
      type: "appointment_reminder",
      title: "Appointment Reminder",
      message: `Your appointment with ${doctor.name} is scheduled in 15 minutes at ${appointment.appointmentTime}. Please arrive 10 minutes early.`,
      appointmentId: args.appointmentId,
    });

    // Mark appointment notification as sent
    await ctx.runMutation(internal.appointments.markNotificationSent, {
      appointmentId: args.appointmentId,
    });
  },
});

// Create notification (internal)
export const createNotification = mutation({
  args: {
    userId: v.id("users"),
    type: v.string(),
    title: v.string(),
    message: v.string(),
    appointmentId: v.optional(v.id("appointments")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("notifications", {
      userId: args.userId,
      type: args.type,
      title: args.title,
      message: args.message,
      scheduledFor: Date.now(),
      sent: false,
      appointmentId: args.appointmentId,
    });
  },
});
