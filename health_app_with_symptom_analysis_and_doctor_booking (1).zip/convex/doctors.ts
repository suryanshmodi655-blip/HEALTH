import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

// Search doctors by location and specialization
export const searchDoctors = query({
  args: {
    specialization: v.optional(v.string()),
    userLat: v.number(),
    userLng: v.number(),
    maxDistance: v.optional(v.number()), // km, default 20
  },
  handler: async (ctx, args) => {
    const maxDist = args.maxDistance || 20;
    let doctors = await ctx.db.query("doctors").collect();

    // Filter by specialization if provided
    if (args.specialization) {
      doctors = doctors.filter(doc => 
        doc.specialization.toLowerCase().includes(args.specialization!.toLowerCase())
      );
    }

    // Calculate distance and filter by radius
    const doctorsWithDistance = doctors
      .map(doctor => {
        const distance = calculateDistance(
          args.userLat,
          args.userLng,
          doctor.location.latitude,
          doctor.location.longitude
        );
        return { ...doctor, distance };
      })
      .filter(doctor => doctor.distance <= maxDist)
      .sort((a, b) => a.distance - b.distance);

    return doctorsWithDistance;
  },
});

// Get doctor details
export const getDoctorById = query({
  args: { doctorId: v.id("doctors") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.doctorId);
  },
});

// Get doctor reviews
export const getDoctorReviews = query({
  args: { doctorId: v.id("doctors") },
  handler: async (ctx, args) => {
    const reviews = await ctx.db
      .query("doctorReviews")
      .withIndex("by_doctor", (q) => q.eq("doctorId", args.doctorId))
      .order("desc")
      .take(20);

    // Get user names for reviews
    const reviewsWithUsers = await Promise.all(
      reviews.map(async (review) => {
        const user = await ctx.db.get(review.userId);
        return {
          ...review,
          userName: user?.name || "Anonymous",
        };
      })
    );

    return reviewsWithUsers;
  },
});

// Add sample doctors (for demo purposes)
export const addSampleDoctors = mutation({
  args: {},
  handler: async (ctx) => {
    const sampleDoctors = [
      {
        name: "Dr. Sarah Johnson",
        specialization: "General Medicine",
        qualifications: ["MBBS", "MD Internal Medicine"],
        experience: 8,
        rating: 4.7,
        reviewCount: 156,
        consultationFee: 500,
        location: {
          address: "123 Health Street, Medical District",
          latitude: 28.6139,
          longitude: 77.2090,
          city: "Delhi",
        },
        availability: [
          { day: "monday", startTime: "09:00", endTime: "17:00" },
          { day: "tuesday", startTime: "09:00", endTime: "17:00" },
          { day: "wednesday", startTime: "09:00", endTime: "17:00" },
          { day: "thursday", startTime: "09:00", endTime: "17:00" },
          { day: "friday", startTime: "09:00", endTime: "17:00" },
          { day: "saturday", startTime: "09:00", endTime: "13:00" },
        ],
        avgConsultationDuration: 15,
        phoneNumber: "+91-9876543210",
        email: "dr.sarah@healthclinic.com",
      },
      {
        name: "Dr. Rajesh Kumar",
        specialization: "Cardiology",
        qualifications: ["MBBS", "MD Cardiology", "DM Interventional Cardiology"],
        experience: 15,
        rating: 4.9,
        reviewCount: 203,
        consultationFee: 800,
        location: {
          address: "456 Heart Care Center, Sector 15",
          latitude: 28.6129,
          longitude: 77.2295,
          city: "Delhi",
        },
        availability: [
          { day: "monday", startTime: "10:00", endTime: "18:00" },
          { day: "tuesday", startTime: "10:00", endTime: "18:00" },
          { day: "wednesday", startTime: "10:00", endTime: "18:00" },
          { day: "thursday", startTime: "10:00", endTime: "18:00" },
          { day: "friday", startTime: "10:00", endTime: "18:00" },
        ],
        avgConsultationDuration: 20,
        phoneNumber: "+91-9876543211",
        email: "dr.rajesh@heartcare.com",
      },
      {
        name: "Dr. Priya Sharma",
        specialization: "Dermatology",
        qualifications: ["MBBS", "MD Dermatology"],
        experience: 6,
        rating: 4.5,
        reviewCount: 89,
        consultationFee: 600,
        location: {
          address: "789 Skin Care Clinic, Green Park",
          latitude: 28.5562,
          longitude: 77.2410,
          city: "Delhi",
        },
        availability: [
          { day: "monday", startTime: "11:00", endTime: "19:00" },
          { day: "tuesday", startTime: "11:00", endTime: "19:00" },
          { day: "wednesday", startTime: "11:00", endTime: "19:00" },
          { day: "friday", startTime: "11:00", endTime: "19:00" },
          { day: "saturday", startTime: "10:00", endTime: "14:00" },
        ],
        avgConsultationDuration: 12,
        phoneNumber: "+91-9876543212",
        email: "dr.priya@skincare.com",
      },
    ];

    for (const doctor of sampleDoctors) {
      await ctx.db.insert("doctors", doctor);
    }

    return "Sample doctors added successfully";
  },
});

// Helper function to calculate distance between two points
function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371; // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}
