import { v } from "convex/values";
import { internalQuery, internalMutation } from "./_generated/server";

// Internal health functions
export const getSymptomReport = internalQuery({
  args: { reportId: v.id("symptomReports") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.reportId);
  },
});

export const getUserProfileById = internalQuery({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique();
  },
});

export const updateSymptomAnalysis = internalMutation({
  args: {
    reportId: v.id("symptomReports"),
    analysis: v.object({
      possibleConditions: v.array(v.object({
        name: v.string(),
        probability: v.number(),
        description: v.string(),
      })),
      recommendedMedicines: v.array(v.object({
        name: v.string(),
        dosage: v.string(),
        frequency: v.string(),
        notes: v.string(),
      })),
      urgencyLevel: v.string(),
      recommendations: v.string(),
    }),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.reportId, {
      analysisResult: args.analysis,
    });
  },
});

// Internal doctor functions
export const getDoctorByIdInternal = internalQuery({
  args: { doctorId: v.id("doctors") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.doctorId);
  },
});

// Internal appointment functions
export const getAppointmentById = internalQuery({
  args: { appointmentId: v.id("appointments") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.appointmentId);
  },
});

export const markNotificationSent = internalMutation({
  args: { appointmentId: v.id("appointments") },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.appointmentId, {
      notificationSent: true,
    });
  },
});
