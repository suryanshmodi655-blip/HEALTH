import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // User health profiles
  userProfiles: defineTable({
    userId: v.id("users"),
    age: v.number(),
    gender: v.string(),
    chronicConditions: v.array(v.string()),
    allergies: v.array(v.string()),
    currentMedications: v.array(v.string()),
  }).index("by_user", ["userId"]),

  // Symptom reports
  symptomReports: defineTable({
    userId: v.id("users"),
    symptoms: v.array(v.object({
      name: v.string(),
      severity: v.number(), // 1-10 scale
      duration: v.string(), // e.g., "2 days", "1 week"
      type: v.string(), // "chronic" or "acute"
    })),
    additionalNotes: v.optional(v.string()),
    analysisResult: v.optional(v.object({
      possibleConditions: v.array(v.object({
        name: v.string(),
        probability: v.number(),
        description: v.string(),
      })),
      recommendedMedicines: v.array(v.object({
        name: v.string(),
        dosage: v.string(),
        frequency: v.string(),
        notes: v.string(),
      })),
      urgencyLevel: v.string(), // "low", "medium", "high", "emergency"
      recommendations: v.string(),
    })),
  }).index("by_user", ["userId"]),

  // Doctors database
  doctors: defineTable({
    name: v.string(),
    specialization: v.string(),
    qualifications: v.array(v.string()),
    experience: v.number(), // years
    rating: v.number(), // 1-5 scale
    reviewCount: v.number(),
    consultationFee: v.number(),
    location: v.object({
      address: v.string(),
      latitude: v.number(),
      longitude: v.number(),
      city: v.string(),
    }),
    availability: v.array(v.object({
      day: v.string(), // "monday", "tuesday", etc.
      startTime: v.string(), // "09:00"
      endTime: v.string(), // "17:00"
    })),
    avgConsultationDuration: v.number(), // minutes
    phoneNumber: v.string(),
    email: v.string(),
  }).index("by_specialization", ["specialization"])
    .index("by_rating", ["rating"])
    .index("by_city", ["location.city"]),

  // Appointments
  appointments: defineTable({
    userId: v.id("users"),
    doctorId: v.id("doctors"),
    appointmentDate: v.string(), // ISO date string
    appointmentTime: v.string(), // "14:30"
    status: v.string(), // "scheduled", "completed", "cancelled", "no-show"
    symptoms: v.array(v.string()),
    notes: v.optional(v.string()),
    estimatedWaitTime: v.number(), // minutes
    notificationSent: v.boolean(),
  }).index("by_user", ["userId"])
    .index("by_doctor", ["doctorId"])
    .index("by_date", ["appointmentDate"])
    .index("by_doctor_and_date", ["doctorId", "appointmentDate"]),

  // Doctor reviews
  doctorReviews: defineTable({
    doctorId: v.id("doctors"),
    userId: v.id("users"),
    rating: v.number(), // 1-5 scale
    review: v.string(),
    appointmentId: v.id("appointments"),
  }).index("by_doctor", ["doctorId"])
    .index("by_user", ["userId"]),

  // Notifications
  notifications: defineTable({
    userId: v.id("users"),
    type: v.string(), // "appointment_reminder", "health_tip", etc.
    title: v.string(),
    message: v.string(),
    scheduledFor: v.number(), // timestamp
    sent: v.boolean(),
    appointmentId: v.optional(v.id("appointments")),
  }).index("by_user", ["userId"])
    .index("by_scheduled_time", ["scheduledFor"])
    .index("by_user_and_sent", ["userId", "sent"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
