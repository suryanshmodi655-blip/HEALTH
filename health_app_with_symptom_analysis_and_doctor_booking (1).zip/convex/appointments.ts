import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";

// Book an appointment
export const bookAppointment = mutation({
  args: {
    doctorId: v.id("doctors"),
    appointmentDate: v.string(),
    appointmentTime: v.string(),
    symptoms: v.array(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Check if slot is available
    const existingAppointment = await ctx.db
      .query("appointments")
      .withIndex("by_doctor_and_date", (q) => 
        q.eq("doctorId", args.doctorId).eq("appointmentDate", args.appointmentDate)
      )
      .filter((q) => q.eq(q.field("appointmentTime"), args.appointmentTime))
      .filter((q) => q.neq(q.field("status"), "cancelled"))
      .first();

    if (existingAppointment) {
      throw new Error("This time slot is already booked");
    }

    // Calculate estimated wait time
    const estimatedWaitTime = await calculateWaitTime(ctx, args.doctorId, args.appointmentDate, args.appointmentTime);

    const appointmentId = await ctx.db.insert("appointments", {
      userId,
      doctorId: args.doctorId,
      appointmentDate: args.appointmentDate,
      appointmentTime: args.appointmentTime,
      status: "scheduled",
      symptoms: args.symptoms,
      notes: args.notes,
      estimatedWaitTime,
      notificationSent: false,
    });

    // Schedule notification 15 minutes before appointment
    const appointmentDateTime = new Date(`${args.appointmentDate}T${args.appointmentTime}`);
    const notificationTime = new Date(appointmentDateTime.getTime() - 15 * 60 * 1000);
    
    if (notificationTime.getTime() > Date.now()) {
      await ctx.scheduler.runAt(notificationTime.getTime(), internal.notifications.sendAppointmentReminder, {
        appointmentId,
      });
    }

    return appointmentId;
  },
});

// Get user's appointments
export const getUserAppointments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const appointments = await ctx.db
      .query("appointments")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(20);

    // Get doctor details for each appointment
    const appointmentsWithDoctors = await Promise.all(
      appointments.map(async (appointment) => {
        const doctor = await ctx.db.get(appointment.doctorId);
        return {
          ...appointment,
          doctor,
        };
      })
    );

    return appointmentsWithDoctors;
  },
});

// Get available time slots for a doctor on a specific date
export const getAvailableSlots = query({
  args: {
    doctorId: v.id("doctors"),
    date: v.string(),
  },
  handler: async (ctx, args) => {
    const doctor = await ctx.db.get(args.doctorId);
    if (!doctor) return [];

    const dayOfWeek = new Date(args.date).toLocaleLowerCase().slice(0, 3);
    const dayMap: Record<string, string> = {
      sun: "sunday",
      mon: "monday",
      tue: "tuesday",
      wed: "wednesday",
      thu: "thursday",
      fri: "friday",
      sat: "saturday",
    };

    const fullDayName = dayMap[dayOfWeek];
    const availability = doctor.availability.find(a => a.day === fullDayName);
    
    if (!availability) return [];

    // Generate time slots
    const slots = generateTimeSlots(availability.startTime, availability.endTime, doctor.avgConsultationDuration);

    // Get booked appointments for this date
    const bookedAppointments = await ctx.db
      .query("appointments")
      .withIndex("by_doctor_and_date", (q) => 
        q.eq("doctorId", args.doctorId).eq("appointmentDate", args.date)
      )
      .filter((q) => q.neq(q.field("status"), "cancelled"))
      .collect();

    const bookedTimes = new Set(bookedAppointments.map(a => a.appointmentTime));

    // Filter out booked slots and past times
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const currentTime = now.getHours() * 60 + now.getMinutes();

    return slots.filter(slot => {
      if (bookedTimes.has(slot)) return false;
      
      // If it's today, filter out past times
      if (args.date === today) {
        const [hours, minutes] = slot.split(':').map(Number);
        const slotTime = hours * 60 + minutes;
        return slotTime > currentTime + 30; // 30 minutes buffer
      }
      
      return true;
    });
  },
});

// Cancel appointment
export const cancelAppointment = mutation({
  args: { appointmentId: v.id("appointments") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const appointment = await ctx.db.get(args.appointmentId);
    if (!appointment || appointment.userId !== userId) {
      throw new Error("Appointment not found or unauthorized");
    }

    await ctx.db.patch(args.appointmentId, {
      status: "cancelled",
    });

    return "Appointment cancelled successfully";
  },
});

// Helper function to calculate estimated wait time
async function calculateWaitTime(ctx: any, doctorId: any, date: string, time: string): Promise<number> {
  const doctor = await ctx.db.get(doctorId);
  if (!doctor) return 0;

  // Get appointments before this time on the same date
  const appointmentsBeforeTime = await ctx.db
    .query("appointments")
    .withIndex("by_doctor_and_date", (q) => 
      q.eq("doctorId", doctorId).eq("appointmentDate", date)
    )
    .filter((q) => q.neq(q.field("status"), "cancelled"))
    .collect();

  const [targetHour, targetMinute] = time.split(':').map(Number);
  const targetTimeInMinutes = targetHour * 60 + targetMinute;

  const earlierAppointments = appointmentsBeforeTime.filter(apt => {
    const [hour, minute] = apt.appointmentTime.split(':').map(Number);
    const aptTimeInMinutes = hour * 60 + minute;
    return aptTimeInMinutes < targetTimeInMinutes;
  });

  // Base wait time: number of earlier appointments * average consultation duration
  const baseWaitTime = earlierAppointments.length * doctor.avgConsultationDuration;
  
  // Add some randomness for emergency cases (0-15 minutes)
  const emergencyBuffer = Math.floor(Math.random() * 16);
  
  return Math.max(0, baseWaitTime + emergencyBuffer);
}

// Helper function to generate time slots
function generateTimeSlots(startTime: string, endTime: string, duration: number): string[] {
  const slots = [];
  const [startHour, startMinute] = startTime.split(':').map(Number);
  const [endHour, endMinute] = endTime.split(':').map(Number);
  
  let currentTime = startHour * 60 + startMinute;
  const endTimeInMinutes = endHour * 60 + endMinute;
  
  while (currentTime < endTimeInMinutes) {
    const hours = Math.floor(currentTime / 60);
    const minutes = currentTime % 60;
    slots.push(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`);
    currentTime += duration;
  }
  
  return slots;
}
