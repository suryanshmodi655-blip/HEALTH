"use node";

import { v } from "convex/values";
import { internalAction, internalMutation } from "./_generated/server";
import { internal } from "./_generated/api";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const analyzeSymptoms = internalAction({
  args: {
    reportId: v.id("symptomReports"),
  },
  handler: async (ctx, args) => {
    const report = await ctx.runQuery(internal.health.getSymptomReport, {
      reportId: args.reportId,
    });

    if (!report) return;

    const userProfile = await ctx.runQuery(internal.health.getUserProfileById, {
      userId: report.userId,
    });

    // Prepare prompt for AI analysis
    const symptomsText = report.symptoms
      .map(s => `${s.name} (severity: ${s.severity}/10, duration: ${s.duration}, type: ${s.type})`)
      .join(", ");

    const profileText = userProfile 
      ? `Age: ${userProfile.age}, Gender: ${userProfile.gender}, Chronic conditions: ${userProfile.chronicConditions.join(", ") || "None"}, Allergies: ${userProfile.allergies.join(", ") || "None"}, Current medications: ${userProfile.currentMedications.join(", ") || "None"}`
      : "No profile information available";

    const prompt = `As a medical AI assistant, analyze these symptoms and provide recommendations. 

Patient Profile: ${profileText}

Symptoms: ${symptomsText}

Additional Notes: ${report.additionalNotes || "None"}

Please provide a JSON response with the following structure:
{
  "possibleConditions": [
    {
      "name": "condition name",
      "probability": 0.8,
      "description": "brief description"
    }
  ],
  "recommendedMedicines": [
    {
      "name": "medicine name",
      "dosage": "dosage amount",
      "frequency": "how often",
      "notes": "important notes or warnings"
    }
  ],
  "urgencyLevel": "low|medium|high|emergency",
  "recommendations": "general recommendations and when to see a doctor"
}

Important: This is for informational purposes only and should not replace professional medical advice. Always recommend consulting a healthcare provider for proper diagnosis and treatment.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.3,
      });

      const content = response.choices[0].message.content;
      if (!content) throw new Error("No response from AI");

      // Parse the JSON response
      const analysis = JSON.parse(content);

      // Update the symptom report with analysis
      await ctx.runMutation(internal.health.updateSymptomAnalysis, {
        reportId: args.reportId,
        analysis,
      });

    } catch (error) {
      console.error("Error analyzing symptoms:", error);
      
      // Provide fallback analysis
      const fallbackAnalysis = {
        possibleConditions: [
          {
            name: "Multiple possible conditions",
            probability: 0.5,
            description: "Symptoms require professional medical evaluation"
          }
        ],
        recommendedMedicines: [
          {
            name: "Consult a healthcare provider",
            dosage: "N/A",
            frequency: "As needed",
            notes: "Professional medical advice required for proper treatment"
          }
        ],
        urgencyLevel: "medium",
        recommendations: "Please consult with a healthcare provider for proper diagnosis and treatment. If symptoms worsen or you experience severe pain, seek immediate medical attention."
      };

      await ctx.runMutation(internal.health.updateSymptomAnalysis, {
        reportId: args.reportId,
        analysis: fallbackAnalysis,
      });
    }
  },
});
