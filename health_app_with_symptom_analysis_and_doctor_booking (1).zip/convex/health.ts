import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api, internal } from "./_generated/api";

// Get user's health profile
export const getUserProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    return await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();
  },
});

// Create or update user health profile
export const updateUserProfile = mutation({
  args: {
    age: v.number(),
    gender: v.string(),
    chronicConditions: v.array(v.string()),
    allergies: v.array(v.string()),
    currentMedications: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const existing = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existing) {
      await ctx.db.patch(existing._id, {
        age: args.age,
        gender: args.gender,
        chronicConditions: args.chronicConditions,
        allergies: args.allergies,
        currentMedications: args.currentMedications,
      });
      return existing._id;
    } else {
      return await ctx.db.insert("userProfiles", {
        userId,
        ...args,
      });
    }
  },
});

// Submit symptoms for analysis
export const submitSymptoms = mutation({
  args: {
    symptoms: v.array(v.object({
      name: v.string(),
      severity: v.number(),
      duration: v.string(),
      type: v.string(),
    })),
    additionalNotes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const reportId = await ctx.db.insert("symptomReports", {
      userId,
      symptoms: args.symptoms,
      additionalNotes: args.additionalNotes,
    });

    // Schedule AI analysis
    await ctx.scheduler.runAfter(0, internal.health.analyzeSymptoms, {
      reportId,
    });

    return reportId;
  },
});

// Get user's symptom reports
export const getSymptomReports = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("symptomReports")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(10);
  },
});

// Get latest symptom analysis
export const getLatestAnalysis = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const reports = await ctx.db
      .query("symptomReports")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(1);

    return reports[0] || null;
  },
});
