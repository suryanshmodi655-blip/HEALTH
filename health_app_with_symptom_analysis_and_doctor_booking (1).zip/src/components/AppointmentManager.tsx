import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function AppointmentManager() {
  const appointments = useQuery(api.appointments.getUserAppointments);
  const cancelAppointment = useMutation(api.appointments.cancelAppointment);

  const handleCancelAppointment = async (appointmentId: string) => {
    if (!confirm("Are you sure you want to cancel this appointment?")) return;

    try {
      await cancelAppointment({ appointmentId: appointmentId as any });
      toast.success("Appointment cancelled successfully");
    } catch (error) {
      toast.error("Failed to cancel appointment");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-green-100 text-green-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      case "no-show":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getUrgencyColor = (waitTime: number) => {
    if (waitTime <= 15) return "text-green-600";
    if (waitTime <= 30) return "text-yellow-600";
    return "text-red-600";
  };

  const isUpcoming = (date: string, time: string) => {
    const appointmentDateTime = new Date(`${date}T${time}`);
    return appointmentDateTime > new Date();
  };

  const upcomingAppointments = appointments?.filter(apt => 
    isUpcoming(apt.appointmentDate, apt.appointmentTime) && apt.status === "scheduled"
  ) || [];

  const pastAppointments = appointments?.filter(apt => 
    !isUpcoming(apt.appointmentDate, apt.appointmentTime) || apt.status !== "scheduled"
  ) || [];

  if (appointments === undefined) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">My Appointments</h2>

      {/* Upcoming Appointments */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Upcoming Appointments ({upcomingAppointments.length})
        </h3>
        
        {upcomingAppointments.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-gray-400 mb-4">
              <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 0V7a2 2 0 012-2h4a2 2 0 012 2v0M8 7v8a2 2 0 002 2h4a2 2 0 002-2V7M8 7H6a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2V9a2 2 0 00-2-2h-2" />
              </svg>
            </div>
            <p className="text-gray-500">No upcoming appointments</p>
            <p className="text-sm text-gray-400 mt-1">Book an appointment with a doctor to get started</p>
          </div>
        ) : (
          <div className="space-y-4">
            {upcomingAppointments.map((appointment) => (
              <div key={appointment._id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">{appointment.doctor?.name}</h4>
                    <p className="text-blue-600 font-medium">{appointment.doctor?.specialization}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(appointment.status)}`}>
                    {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">
                      <strong>Date & Time:</strong> {new Date(appointment.appointmentDate).toLocaleDateString()} at {appointment.appointmentTime}
                    </p>
                    <p className="text-sm text-gray-600 mb-1">
                      <strong>Consultation Fee:</strong> ₹{appointment.doctor?.consultationFee}
                    </p>
                    <p className="text-sm text-gray-600">
                      <strong>Location:</strong> {appointment.doctor?.location.address}
                    </p>
                  </div>
                  
                  <div>
                    <p className={`text-sm font-medium mb-1 ${getUrgencyColor(appointment.estimatedWaitTime)}`}>
                      <strong>Estimated Wait Time:</strong> {appointment.estimatedWaitTime} minutes
                    </p>
                    <p className="text-sm text-gray-600 mb-1">
                      <strong>Contact:</strong> {appointment.doctor?.phoneNumber}
                    </p>
                    {appointment.notificationSent && (
                      <p className="text-sm text-green-600">
                        ✓ Reminder notification sent
                      </p>
                    )}
                  </div>
                </div>

                {appointment.symptoms.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-700 mb-1">Symptoms:</p>
                    <div className="flex flex-wrap gap-1">
                      {appointment.symptoms.map((symptom, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                        >
                          {symptom}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {appointment.notes && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-700 mb-1">Notes:</p>
                    <p className="text-sm text-gray-600">{appointment.notes}</p>
                  </div>
                )}

                <div className="flex space-x-3">
                  <button
                    onClick={() => handleCancelAppointment(appointment._id)}
                    className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors text-sm"
                  >
                    Cancel Appointment
                  </button>
                  <a
                    href={`tel:${appointment.doctor?.phoneNumber}`}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors text-sm"
                  >
                    Call Doctor
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Past Appointments */}
      {pastAppointments.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Past Appointments ({pastAppointments.length})
          </h3>
          
          <div className="space-y-4">
            {pastAppointments.map((appointment) => (
              <div key={appointment._id} className="border border-gray-200 rounded-lg p-4 opacity-75">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">{appointment.doctor?.name}</h4>
                    <p className="text-blue-600 font-medium">{appointment.doctor?.specialization}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(appointment.status)}`}>
                    {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">
                      <strong>Date & Time:</strong> {new Date(appointment.appointmentDate).toLocaleDateString()} at {appointment.appointmentTime}
                    </p>
                    <p className="text-sm text-gray-600">
                      <strong>Consultation Fee:</strong> ₹{appointment.doctor?.consultationFee}
                    </p>
                  </div>
                  
                  <div>
                    {appointment.symptoms.length > 0 && (
                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-1">Symptoms:</p>
                        <div className="flex flex-wrap gap-1">
                          {appointment.symptoms.slice(0, 3).map((symptom, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                            >
                              {symptom}
                            </span>
                          ))}
                          {appointment.symptoms.length > 3 && (
                            <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                              +{appointment.symptoms.length - 3} more
                            </span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tips */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-2">Appointment Tips</h3>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Arrive 10-15 minutes early for your appointment</li>
          <li>• Bring a list of current medications and medical history</li>
          <li>• You'll receive a notification 15 minutes before your appointment</li>
          <li>• Wait times are estimates and may vary due to emergency cases</li>
          <li>• Contact the doctor directly if you need to reschedule</li>
        </ul>
      </div>
    </div>
  );
}
