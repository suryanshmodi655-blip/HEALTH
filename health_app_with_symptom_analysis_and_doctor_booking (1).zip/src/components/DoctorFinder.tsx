import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function DoctorFinder() {
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [specialization, setSpecialization] = useState("");
  const [selectedDoctor, setSelectedDoctor] = useState<any>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);

  const addSampleDoctors = useMutation(api.doctors.addSampleDoctors);

  // Get user's location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        () => {
          // Default to Delhi coordinates if location access denied
          setUserLocation({ lat: 28.6139, lng: 77.2090 });
          toast.info("Using default location (Delhi). Enable location access for better results.");
        }
      );
    } else {
      setUserLocation({ lat: 28.6139, lng: 77.2090 });
    }
  }, []);

  const doctors = useQuery(
    api.doctors.searchDoctors,
    userLocation
      ? {
          specialization: specialization || undefined,
          userLat: userLocation.lat,
          userLng: userLocation.lng,
          maxDistance: 20,
        }
      : "skip"
  );

  const handleAddSampleDoctors = async () => {
    try {
      await addSampleDoctors();
      toast.success("Sample doctors added successfully!");
    } catch (error) {
      toast.error("Failed to add sample doctors");
    }
  };

  const specializations = [
    "General Medicine",
    "Cardiology",
    "Dermatology",
    "Orthopedics",
    "Pediatrics",
    "Gynecology",
    "Neurology",
    "Psychiatry",
    "ENT",
    "Ophthalmology",
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Find Doctors</h2>
          <button
            onClick={handleAddSampleDoctors}
            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm"
          >
            Add Sample Doctors
          </button>
        </div>

        {/* Search Filters */}
        <div className="mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Specialization
              </label>
              <select
                value={specialization}
                onChange={(e) => setSpecialization(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Specializations</option>
                {specializations.map((spec) => (
                  <option key={spec} value={spec}>
                    {spec}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Location Status
              </label>
              <div className="px-3 py-2 bg-gray-50 border border-gray-300 rounded-md">
                {userLocation ? (
                  <span className="text-green-600">📍 Location detected</span>
                ) : (
                  <span className="text-yellow-600">📍 Getting location...</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Doctors List */}
        {doctors === undefined ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : doctors.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No doctors found in your area. Try adding sample doctors first.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {doctors.map((doctor) => (
              <div key={doctor._id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{doctor.name}</h3>
                    <p className="text-blue-600 font-medium">{doctor.specialization}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center">
                      <span className="text-yellow-500">⭐</span>
                      <span className="ml-1 text-sm font-medium">{doctor.rating}</span>
                      <span className="text-xs text-gray-500 ml-1">({doctor.reviewCount})</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <p className="text-sm text-gray-600">
                    <strong>Experience:</strong> {doctor.experience} years
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Consultation Fee:</strong> ₹{doctor.consultationFee}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Distance:</strong> {doctor.distance.toFixed(1)} km away
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Avg. Consultation:</strong> {doctor.avgConsultationDuration} minutes
                  </p>
                </div>

                <div className="mb-4">
                  <p className="text-sm font-medium text-gray-700 mb-1">Qualifications:</p>
                  <div className="flex flex-wrap gap-1">
                    {doctor.qualifications.map((qual, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                      >
                        {qual}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-sm text-gray-600">{doctor.location.address}</p>
                </div>

                <div className="flex space-x-2">
                  <button
                    onClick={() => {
                      setSelectedDoctor(doctor);
                      setShowBookingModal(true);
                    }}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                  >
                    Book Appointment
                  </button>
                  <button
                    onClick={() => setSelectedDoctor(doctor)}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors text-sm"
                  >
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Doctor Details Modal */}
      {selectedDoctor && !showBookingModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">{selectedDoctor.name}</h3>
                  <p className="text-blue-600 font-medium text-lg">{selectedDoctor.specialization}</p>
                </div>
                <button
                  onClick={() => setSelectedDoctor(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Professional Details</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong>Experience:</strong> {selectedDoctor.experience} years</p>
                    <p><strong>Rating:</strong> ⭐ {selectedDoctor.rating} ({selectedDoctor.reviewCount} reviews)</p>
                    <p><strong>Consultation Fee:</strong> ₹{selectedDoctor.consultationFee}</p>
                    <p><strong>Avg. Consultation Time:</strong> {selectedDoctor.avgConsultationDuration} minutes</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Contact Information</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong>Phone:</strong> {selectedDoctor.phoneNumber}</p>
                    <p><strong>Email:</strong> {selectedDoctor.email}</p>
                    <p><strong>Address:</strong> {selectedDoctor.location.address}</p>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="font-semibold text-gray-900 mb-2">Availability</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {selectedDoctor.availability.map((slot: any, index: number) => (
                    <div key={index} className="p-2 bg-gray-50 rounded text-sm">
                      <p className="font-medium capitalize">{slot.day}</p>
                      <p className="text-gray-600">{slot.startTime} - {slot.endTime}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex space-x-4">
                <button
                  onClick={() => setShowBookingModal(true)}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  Book Appointment
                </button>
                <button
                  onClick={() => setSelectedDoctor(null)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Booking Modal */}
      {showBookingModal && selectedDoctor && (
        <BookingModal
          doctor={selectedDoctor}
          onClose={() => {
            setShowBookingModal(false);
            setSelectedDoctor(null);
          }}
        />
      )}
    </div>
  );
}

function BookingModal({ doctor, onClose }: { doctor: any; onClose: () => void }) {
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [symptoms, setSymptoms] = useState<string[]>([]);
  const [currentSymptom, setCurrentSymptom] = useState("");
  const [notes, setNotes] = useState("");
  const [isBooking, setIsBooking] = useState(false);

  const bookAppointment = useMutation(api.appointments.bookAppointment);
  const availableSlots = useQuery(
    api.appointments.getAvailableSlots,
    selectedDate ? { doctorId: doctor._id, date: selectedDate } : "skip"
  );

  // Generate next 7 days for date selection
  const getNextSevenDays = () => {
    const days = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      days.push(date.toISOString().split('T')[0]);
    }
    return days;
  };

  const addSymptom = () => {
    if (currentSymptom.trim() && !symptoms.includes(currentSymptom.trim())) {
      setSymptoms([...symptoms, currentSymptom.trim()]);
      setCurrentSymptom("");
    }
  };

  const removeSymptom = (symptom: string) => {
    setSymptoms(symptoms.filter(s => s !== symptom));
  };

  const handleBooking = async () => {
    if (!selectedDate || !selectedTime) {
      toast.error("Please select date and time");
      return;
    }

    if (symptoms.length === 0) {
      toast.error("Please add at least one symptom");
      return;
    }

    setIsBooking(true);
    try {
      await bookAppointment({
        doctorId: doctor._id,
        appointmentDate: selectedDate,
        appointmentTime: selectedTime,
        symptoms,
        notes: notes || undefined,
      });
      toast.success("Appointment booked successfully!");
      onClose();
    } catch (error: any) {
      toast.error(error.message || "Failed to book appointment");
    } finally {
      setIsBooking(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-xl font-bold text-gray-900">Book Appointment</h3>
              <p className="text-gray-600">{doctor.name} - {doctor.specialization}</p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              ✕
            </button>
          </div>

          <div className="space-y-6">
            {/* Date Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Date
              </label>
              <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                {getNextSevenDays().map((date) => {
                  const dateObj = new Date(date);
                  const isToday = date === new Date().toISOString().split('T')[0];
                  return (
                    <button
                      key={date}
                      onClick={() => {
                        setSelectedDate(date);
                        setSelectedTime("");
                      }}
                      className={`p-2 text-sm rounded-md border ${
                        selectedDate === date
                          ? "bg-blue-600 text-white border-blue-600"
                          : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"
                      }`}
                    >
                      <div className="font-medium">
                        {isToday ? "Today" : dateObj.toLocaleDateString('en', { weekday: 'short' })}
                      </div>
                      <div className="text-xs">
                        {dateObj.toLocaleDateString('en', { month: 'short', day: 'numeric' })}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Time Selection */}
            {selectedDate && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Time
                </label>
                {availableSlots === undefined ? (
                  <div className="flex justify-center py-4">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                  </div>
                ) : availableSlots.length === 0 ? (
                  <p className="text-gray-500 text-sm">No available slots for this date</p>
                ) : (
                  <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                    {availableSlots.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`p-2 text-sm rounded-md border ${
                          selectedTime === time
                            ? "bg-blue-600 text-white border-blue-600"
                            : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Symptoms */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Symptoms
              </label>
              <div className="flex space-x-2 mb-2">
                <input
                  type="text"
                  value={currentSymptom}
                  onChange={(e) => setCurrentSymptom(e.target.value)}
                  placeholder="Enter symptom"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onKeyPress={(e) => e.key === 'Enter' && addSymptom()}
                />
                <button
                  onClick={addSymptom}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  Add
                </button>
              </div>
              {symptoms.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {symptoms.map((symptom) => (
                    <span
                      key={symptom}
                      className="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full"
                    >
                      {symptom}
                      <button
                        onClick={() => removeSymptom(symptom)}
                        className="ml-2 text-blue-600 hover:text-blue-800"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Additional Notes (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any additional information..."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Booking Summary */}
            {selectedDate && selectedTime && (
              <div className="p-4 bg-gray-50 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-2">Booking Summary</h4>
                <div className="text-sm space-y-1">
                  <p><strong>Doctor:</strong> {doctor.name}</p>
                  <p><strong>Date:</strong> {new Date(selectedDate).toLocaleDateString()}</p>
                  <p><strong>Time:</strong> {selectedTime}</p>
                  <p><strong>Consultation Fee:</strong> ₹{doctor.consultationFee}</p>
                  <p><strong>Estimated Duration:</strong> {doctor.avgConsultationDuration} minutes</p>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <button
                onClick={handleBooking}
                disabled={isBooking || !selectedDate || !selectedTime || symptoms.length === 0}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isBooking ? "Booking..." : "Confirm Booking"}
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
