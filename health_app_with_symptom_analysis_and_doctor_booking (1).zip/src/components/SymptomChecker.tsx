import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface Symptom {
  name: string;
  severity: number;
  duration: string;
  type: string;
}

export function SymptomChecker() {
  const [symptoms, setSymptoms] = useState<Symptom[]>([]);
  const [currentSymptom, setCurrentSymptom] = useState({
    name: "",
    severity: 5,
    duration: "",
    type: "acute",
  });
  const [additionalNotes, setAdditionalNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submitSymptoms = useMutation(api.health.submitSymptoms);
  const latestAnalysis = useQuery(api.health.getLatestAnalysis);

  const addSymptom = () => {
    if (!currentSymptom.name || !currentSymptom.duration) {
      toast.error("Please fill in all symptom details");
      return;
    }

    setSymptoms([...symptoms, currentSymptom]);
    setCurrentSymptom({
      name: "",
      severity: 5,
      duration: "",
      type: "acute",
    });
  };

  const removeSymptom = (index: number) => {
    setSymptoms(symptoms.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (symptoms.length === 0) {
      toast.error("Please add at least one symptom");
      return;
    }

    setIsSubmitting(true);
    try {
      await submitSymptoms({
        symptoms,
        additionalNotes: additionalNotes || undefined,
      });
      toast.success("Symptoms submitted for analysis");
      setSymptoms([]);
      setAdditionalNotes("");
    } catch (error) {
      toast.error("Failed to submit symptoms");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Symptom Checker</h2>
        
        {/* Add Symptom Form */}
        <div className="space-y-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Symptom Name
              </label>
              <input
                type="text"
                value={currentSymptom.name}
                onChange={(e) => setCurrentSymptom({ ...currentSymptom, name: e.target.value })}
                placeholder="e.g., Headache, Fever, Cough"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Duration
              </label>
              <input
                type="text"
                value={currentSymptom.duration}
                onChange={(e) => setCurrentSymptom({ ...currentSymptom, duration: e.target.value })}
                placeholder="e.g., 2 days, 1 week"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Severity (1-10)
              </label>
              <input
                type="range"
                min="1"
                max="10"
                value={currentSymptom.severity}
                onChange={(e) => setCurrentSymptom({ ...currentSymptom, severity: parseInt(e.target.value) })}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Mild (1)</span>
                <span className="font-medium">{currentSymptom.severity}</span>
                <span>Severe (10)</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Type
              </label>
              <select
                value={currentSymptom.type}
                onChange={(e) => setCurrentSymptom({ ...currentSymptom, type: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="acute">Acute (Recent onset)</option>
                <option value="chronic">Chronic (Long-term)</option>
              </select>
            </div>
          </div>

          <button
            onClick={addSymptom}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Add Symptom
          </button>
        </div>

        {/* Current Symptoms List */}
        {symptoms.length > 0 && (
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Current Symptoms</h3>
            <div className="space-y-2">
              {symptoms.map((symptom, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <span className="font-medium text-gray-900">{symptom.name}</span>
                    <span className="text-sm text-gray-600 ml-2">
                      (Severity: {symptom.severity}/10, Duration: {symptom.duration}, Type: {symptom.type})
                    </span>
                  </div>
                  <button
                    onClick={() => removeSymptom(index)}
                    className="text-red-600 hover:text-red-800"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Additional Notes */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Additional Notes (Optional)
          </label>
          <textarea
            value={additionalNotes}
            onChange={(e) => setAdditionalNotes(e.target.value)}
            placeholder="Any additional information about your symptoms..."
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Submit Button */}
        <button
          onClick={handleSubmit}
          disabled={isSubmitting || symptoms.length === 0}
          className="w-full px-4 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isSubmitting ? "Analyzing..." : "Analyze Symptoms"}
        </button>
      </div>

      {/* Analysis Results */}
      {latestAnalysis?.analysisResult && (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Analysis Results</h3>
          
          {/* Urgency Level */}
          <div className={`p-4 rounded-lg mb-6 ${
            latestAnalysis.analysisResult.urgencyLevel === 'emergency' 
              ? 'bg-red-100 border border-red-300' 
              : latestAnalysis.analysisResult.urgencyLevel === 'high'
              ? 'bg-orange-100 border border-orange-300'
              : latestAnalysis.analysisResult.urgencyLevel === 'medium'
              ? 'bg-yellow-100 border border-yellow-300'
              : 'bg-green-100 border border-green-300'
          }`}>
            <h4 className="font-semibold text-gray-900 mb-2">
              Urgency Level: {latestAnalysis.analysisResult.urgencyLevel.toUpperCase()}
            </h4>
            <p className="text-gray-700">{latestAnalysis.analysisResult.recommendations}</p>
          </div>

          {/* Possible Conditions */}
          <div className="mb-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-3">Possible Conditions</h4>
            <div className="space-y-3">
              {latestAnalysis.analysisResult.possibleConditions.map((condition, index) => (
                <div key={index} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h5 className="font-medium text-gray-900">{condition.name}</h5>
                    <span className="text-sm font-medium text-blue-600">
                      {Math.round(condition.probability * 100)}% match
                    </span>
                  </div>
                  <p className="text-gray-700">{condition.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Recommended Medicines */}
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-3">Recommended Medicines</h4>
            <div className="space-y-3">
              {latestAnalysis.analysisResult.recommendedMedicines.map((medicine, index) => (
                <div key={index} className="p-4 bg-blue-50 rounded-lg">
                  <h5 className="font-medium text-gray-900 mb-1">{medicine.name}</h5>
                  <p className="text-sm text-gray-600 mb-1">
                    <strong>Dosage:</strong> {medicine.dosage} | <strong>Frequency:</strong> {medicine.frequency}
                  </p>
                  <p className="text-sm text-gray-700">{medicine.notes}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              <strong>Disclaimer:</strong> This analysis is for informational purposes only and should not replace professional medical advice. 
              Please consult with a healthcare provider for proper diagnosis and treatment.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
